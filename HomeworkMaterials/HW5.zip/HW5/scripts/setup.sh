#!/bin/bash
ln -s ../images/frontend ../compose/frontend
ln -s ../images/backend ../compose/backend
